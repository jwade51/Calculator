package SESSIONS;

public class Driver {
	public static void main(String[] args) {
		Baby human = new Baby();
		human.BabyToddler();
		human.BabynewBorn();
		Adult human2= new Adult();
		human2.Old();
		human2.Young();
		human2.BarelyLegal();
		human2.abstractMethod();
		Elder human3= new Elder();
		human3.FortyandFine();
		human3.FiftyandOld();
		human3.OldDust();
		
	
	System.out.println("Done");
	}
}
