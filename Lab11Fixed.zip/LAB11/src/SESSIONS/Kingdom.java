package SESSIONS;

public abstract class Kingdom {
	
	public void concreteKingdom() {
		System.out.println(" Concrete method of Kingdom");
	}

	
	abstract public void abstractMethod();

}
