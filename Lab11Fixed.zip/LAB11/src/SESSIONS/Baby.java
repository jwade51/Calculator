package SESSIONS;

public class Baby {
	
	public Baby() {
		System.out.println(" concrete class 1:baby");
	}
	public void BabyToddler(){
		System.out.println("Method 1 of Baby");
	}
	public void BabynewBorn() {
		System.out.println("Method two of Baby");
	}
	
		// TODO Auto-generated method stub
		
	}


