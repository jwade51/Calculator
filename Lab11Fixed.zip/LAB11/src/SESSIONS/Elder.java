package SESSIONS;

public class Elder extends Baby {

	public Elder() {
		super();
		System.out.println("Constructor");
	}
	public void FortyandFine() {
		System.out.println("Method of Baby");
	}
	public void FiftyandOld() {
		System.out.println("Method 2 of Baby");
		
	}
	
	public void OldDust() {
		System.out.println("Method 3 of Baby");
	}

		
	}

