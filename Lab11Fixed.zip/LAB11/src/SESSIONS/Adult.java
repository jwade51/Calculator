package SESSIONS;

public class Adult extends Kingdom {
	public void BarelyLegal() {
		System.out.println(" Concrete class 2 of Adult/ barely made it");
		
	}
	public void Young() {
		System.out.println("Method one of Concrete Adult");
		
	}
	public void Old() {
		System.out.println("Method two of Concrete Adult");
	}
	
	public void abstractMethod() {
		System.out.println("Abstract method");
	}
	

}
